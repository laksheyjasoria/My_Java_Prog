package colletions;

import java.util.TreeSet;
public class TreeSetHetro {

	public static void main(String[] args) {
		TreeSet tSet =new TreeSet();
	tSet.add(87);
	tSet.add(78.0);
	tSet.add(true);
	tSet.add("helo");
	tSet.add(90);
	tSet.add(900);
	System.out.println(tSet);
//	for (Object object : tSet) {
//		System.out.println(object);
	}
	}

