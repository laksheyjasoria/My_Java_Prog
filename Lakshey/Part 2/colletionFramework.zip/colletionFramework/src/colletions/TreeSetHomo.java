package colletions;

import java.util.TreeSet;

public class TreeSetHomo {

	public static void main(String[] args) {
		TreeSet<Integer> tSet =new TreeSet();
	tSet.add(87);
	tSet.add(78);
	tSet.add(279);
	tSet.add(90);
	tSet.add(90);
	tSet.add(900);
	System.out.println(tSet);
//	for (Object object : tSet) {
//		System.out.println(object);
	}
	}

