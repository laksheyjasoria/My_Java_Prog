package multiplication;

public class Multiplication {

//	public static void main(String[] args) {
//		System.out.println(multiply(4,5));
//	}
	public static int multiply(int a, int b) {
     return a*b;
	}

}
