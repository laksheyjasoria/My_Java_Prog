package subtraction;

public class Subtraction {

//	public static void main(String[] args) {
//		Subtraction s1= new Subtraction();
//		System.out.println(s1.sub(5,2));
//	}
	public int sub(int a,int b) {
		return a-b;
	}

}
