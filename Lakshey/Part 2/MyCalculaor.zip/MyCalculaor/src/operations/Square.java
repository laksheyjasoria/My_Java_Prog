package operations;

public class Square {

	public static void main(String[] args) {
     System.out.println(sq(4));
	}
    public static int sq(int base) {
		return base*base;
	}
}
