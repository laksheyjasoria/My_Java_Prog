package addition;

class Additon {
// public static void main(String[] args) {
// System.out.println(add(6,8));
//}
 public static int add(int num1,int num2) {
	return num1+num2;
}
}
